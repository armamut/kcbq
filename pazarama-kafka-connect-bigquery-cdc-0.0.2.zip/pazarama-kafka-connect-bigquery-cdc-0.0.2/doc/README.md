# Kafka Connect BigQuery CDC Sink Connector

A Kafka Connect sink connector for BigQuery with Change Data Capture (CDC) support. This connector reads Debezium CDC messages from Kafka topics and writes them to BigQuery using the Storage Write API.

## Features

- ✅ **Dual CDC Support**: Works with both MongoDB and MSSQL Debezium CDC sources
- ✅ **Auto Schema Management**: Automatically creates tables and updates schemas
- ✅ **Table Partitioning**: Support for time-based and column-based partitioning (HOUR, DAY, MONTH, YEAR)
- ✅ **GUID Conversion**: Converts binary GUIDs to string format (MongoDB CDC)
- ✅ **Type Inference**: Smart type inference including handling null values in arrays
- ✅ **Nested Structures**: Supports nested objects (RECORD) and arrays (REPEATED)
- ✅ **Null Filtering**: Optionally removes null values before writing
- ✅ **Batching & Retries**: Configurable batching and automatic retry logic
- ✅ **BigQuery Storage Write API**: Uses efficient streaming inserts
- ✅ **Cost Optimization**: Partition expiration and query filtering for reduced costs

## Architecture

```
Debezium CDC → Kafka Topic → Kafka Connect → BigQuery Sink Connector → BigQuery Table
```

### Processing Flow

1. **Extract**: Reads CDC messages from Kafka using `$.payload.after` JSONPath
2. **Transform**: 
   - MongoDB CDC: Converts binary GUIDs, processes BSON types ($date, $numberLong)
   - MSSQL CDC: Processes structured data directly
3. **Filter**: Optionally removes null values
4. **Schema**: Infers or updates BigQuery table schema
5. **Load**: Writes data to BigQuery in batches

## Prerequisites

- Java 11 or higher
- Apache Kafka 2.x or 3.x
- Kafka Connect (distributed or standalone)
- Google Cloud Platform account with BigQuery enabled
- Service Account with BigQuery permissions:
  - `bigquery.datasets.get`
  - `bigquery.tables.create`
  - `bigquery.tables.update`
  - `bigquery.tables.updateData`
  - `bigquery.tables.get`

## Installation

### Build from Source

Use WSL (Windows Subsystem for Linux) to run Maven commands:

```bash
# Navigate to project directory
cd /mnt/c/Users/arma.mut/repos/kafka-connect-bigquery-cdc-sink-connector

# Build the project
./build.sh

# Or manually with Maven
mvn clean package
```

This creates an uber JAR in `target/kafka-connect-bigquery-cdc-sink-0.0.2-jar-with-dependencies.jar`

### Deploy to Kafka Connect

1. Copy the JAR file to your Kafka Connect `plugins` directory:

```bash
mkdir -p /path/to/kafka-connect/plugins/bigquery-cdc-sink
cp target/kafka-connect-bigquery-cdc-sink-*.jar /path/to/kafka-connect/plugins/bigquery-cdc-sink/
```

2. Restart Kafka Connect workers

3. Verify the connector is available:

```bash
curl http://localhost:8083/connector-plugins | jq
```

You should see `com.pazarama.connector.bigquery.BigQuerySinkConnector` in the list.

## Configuration

### MongoDB CDC Configuration

```properties
# Connector Configuration
name=bigquery-mongodb-cdc-sink
connector.class=com.pazarama.connector.bigquery.BigQuerySinkConnector
tasks.max=1

# Topics
topics=mongodb.Order.Order

# BigQuery Settings
bigquery.project.id=your-gcp-project-id
bigquery.dataset=your_dataset_name
bigquery.table.name.format=${topic}
bigquery.location=US
bigquery.keyfile=/path/to/service-account-key.json

# CDC Settings
cdc.type=MONGODB
cdc.payload.field=$.payload.after
bigquery.primary.key.field=_id

# Schema Settings
bigquery.auto.create.tables=true
bigquery.sanitize.field.names=true
bigquery.allow.schema.update=true

# Write Settings
bigquery.batch.size=1000
bigquery.batch.timeout.ms=30000
bigquery.max.retries=5
bigquery.retry.backoff.ms=1000
bigquery.filter.null.values=true

# Converters
key.converter=org.apache.kafka.connect.json.JsonConverter
key.converter.schemas.enable=false
value.converter=org.apache.kafka.connect.json.JsonConverter
value.converter.schemas.enable=true
```

### MSSQL CDC Configuration

```properties
# Connector Configuration
name=bigquery-mssql-cdc-sink
connector.class=com.pazarama.connector.bigquery.BigQuerySinkConnector
tasks.max=1

# Topics
topics=mssql.Catalog.dbo.ProductSeller

# BigQuery Settings
bigquery.project.id=your-gcp-project-id
bigquery.dataset=your_dataset_name
bigquery.table.name.format=${topic}
bigquery.location=US
bigquery.keyfile=/path/to/service-account-key.json

# CDC Settings
cdc.type=MSSQL
cdc.payload.field=$.payload.after
bigquery.primary.key.field=Id

# Schema Settings
bigquery.auto.create.tables=true
bigquery.sanitize.field.names=true
bigquery.allow.schema.update=true

# Write Settings
bigquery.batch.size=1000
bigquery.batch.timeout.ms=30000
bigquery.max.retries=5
bigquery.retry.backoff.ms=1000
bigquery.filter.null.values=true

# Converters
key.converter=org.apache.kafka.connect.json.JsonConverter
key.converter.schemas.enable=false
value.converter=org.apache.kafka.connect.json.JsonConverter
value.converter.schemas.enable=true
```

## Configuration Reference

### BigQuery Settings

| Property | Description | Default | Required |
|----------|-------------|---------|----------|
| `bigquery.project.id` | GCP Project ID | - | Yes |
| `bigquery.dataset` | BigQuery dataset name | - | Yes |
| `bigquery.table.name.format` | Table name format (`${topic}` placeholder) | `${topic}` | No |
| `bigquery.location` | BigQuery dataset location | `US` | No |
| `bigquery.keyfile` | Path to service account JSON key | null (uses ADC) | No |

### CDC Settings

| Property | Description | Default | Required |
|----------|-------------|---------|----------|
| `cdc.type` | CDC source type: `MONGODB` or `MSSQL` | `MONGODB` | No |
| `cdc.payload.field` | JSONPath to extract payload | `$.payload.after` | No |
| `bigquery.primary.key.field` | Primary key field name | `_id` | No |

### Schema Settings

| Property | Description | Default | Required |
|----------|-------------|---------|----------|
| `bigquery.auto.create.tables` | Auto-create tables if not exist | `true` | No |
| `bigquery.sanitize.field.names` | Sanitize field names for BigQuery | `true` | No |
| `bigquery.allow.schema.update` | Allow schema updates for new fields | `true` | No |

### Write Settings

| Property | Description | Default | Required |
|----------|-------------|---------|----------|
| `bigquery.batch.size` | Max records per batch | `1000` | No |
| `bigquery.batch.timeout.ms` | Max time to wait before flush (ms) | `30000` | No |
| `bigquery.max.retries` | Max retries for failed writes | `5` | No |
| `bigquery.retry.backoff.ms` | Backoff between retries (ms) | `1000` | No |
| `bigquery.filter.null.values` | Remove null values before write | `true` | No |

### CDC Table Settings

| Property | Description | Default | Required |
|----------|-------------|---------|----------|
| `bigquery.cdc.enabled` | Enable CDC table features (PRIMARY KEY) | `true` | No |
| `bigquery.max.staleness.minutes` | CDC max_staleness interval | `15` | No |
| `bigquery.use.clustering` | Enable clustering by primary key | `true` | No |

### Partition Settings

| Property | Description | Default | Required |
|----------|-------------|---------|----------|
| `bigquery.partition.enabled` | Enable table partitioning | `false` | No |
| `bigquery.partition.field` | Partition field (`_PARTITIONTIME` or field name) | `_PARTITIONTIME` | No |
| `bigquery.partition.type` | Partition granularity (HOUR, DAY, MONTH, YEAR) | `DAY` | No |
| `bigquery.partition.expiration.ms` | Partition expiration in milliseconds (0 = never) | `0` | No |
| `bigquery.require.partition.filter` | Require partition filter in queries | `false` | No |

**See [PARTITIONING.md](PARTITIONING.md) for detailed partition configuration guide.**

## Data Type Mapping

### MongoDB CDC

| MongoDB/BSON Type | BigQuery Type | Notes |
|-------------------|---------------|-------|
| `$binary` (type 03/04) | `STRING` | Converted to GUID string |
| `$date` | `INT64` | Unix timestamp in milliseconds |
| `$numberLong` | `INT64` | Long integer |
| String | `STRING` | - |
| Number | `INT64` / `FLOAT64` | Based on value |
| Boolean | `BOOL` | - |
| Object | `STRUCT` (RECORD) | Nested object |
| Array | `REPEATED` | Array type |
| null | - | Filtered out (configurable) |

### MSSQL CDC

| SQL Server Type | BigQuery Type | Notes |
|-----------------|---------------|-------|
| VARCHAR, NVARCHAR, CHAR | `STRING` | - |
| INT, BIGINT | `INT64` | - |
| SMALLINT, TINYINT | `INT64` | - |
| DECIMAL, NUMERIC, FLOAT, REAL | `FLOAT64` | - |
| BIT | `BOOL` | - |
| DATETIME, TIMESTAMP | `INT64` | Unix timestamp |
| UNIQUEIDENTIFIER (GUID) | `STRING` | - |

## Examples

### Deploy Connector (Standalone Mode)

```bash
# Edit configuration
vi config/connector.properties

# Start connector in standalone mode
connect-standalone config/worker.properties config/connector.properties
```

### Deploy Connector (Distributed Mode)

```bash
# Create connector via REST API
curl -X POST http://localhost:8083/connectors \
  -H "Content-Type: application/json" \
  -d @config/connector.json
```

Example `connector.json`:

```json
{
  "name": "bigquery-cdc-sink",
  "config": {
    "connector.class": "com.pazarama.connector.bigquery.BigQuerySinkConnector",
    "tasks.max": "1",
    "topics": "mongodb.Order.Order",
    "bigquery.project.id": "your-project-id",
    "bigquery.dataset": "your_dataset",
    "bigquery.keyfile": "/path/to/keyfile.json",
    "cdc.type": "MONGODB",
    "cdc.payload.field": "$.payload.after",
    "bigquery.filter.null.values": "true",
    "key.converter": "org.apache.kafka.connect.json.JsonConverter",
    "key.converter.schemas.enable": "false",
    "value.converter": "org.apache.kafka.connect.json.JsonConverter",
    "value.converter.schemas.enable": "true"
  }
}
```

### Monitor Connector

```bash
# Check connector status
curl http://localhost:8083/connectors/bigquery-cdc-sink/status | jq

# Check connector config
curl http://localhost:8083/connectors/bigquery-cdc-sink/config | jq

# Delete connector
curl -X DELETE http://localhost:8083/connectors/bigquery-cdc-sink
```

## Testing

Run unit tests:

```bash
mvn test
```

Run specific test:

```bash
mvn test -Dtest=GuidConverterTest
mvn test -Dtest=JsonPayloadProcessorTest
```

## Troubleshooting

### Common Issues

**1. Authentication Errors**

```
Error: Your default credentials were not found
Error: Failed to create BigQueryWriteClient
```

**Solutions**:
- **Option 1 (Recommended)**: Set `bigquery.keyfile` in your connector configuration:
  ```properties
  bigquery.keyfile=/path/to/service-account-key.json
  ```
  Or provide the JSON content directly:
  ```properties
  bigquery.keyfile={"type":"service_account","project_id":"..."}
  ```

- **Option 2**: Set up Application Default Credentials (ADC):
  ```bash
  # Set environment variable
  export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account-key.json
  
  # Or use gcloud auth
  gcloud auth application-default login
  ```

- **Required Permissions**: Ensure your service account has:
  - `bigquery.datasets.get`
  - `bigquery.tables.create`
  - `bigquery.tables.update`
  - `bigquery.tables.updateData`
  - `bigquery.tables.get`

**2. Table Not Found**

```
Error: Table does not exist and auto-create is disabled
```

**Solution**: Set `bigquery.auto.create.tables=true` or create the table manually.

**3. Schema Mismatch**

```
Error: Field not found in table schema
```

**Solution**: Set `bigquery.allow.schema.update=true` to allow schema updates.

**4. Null Pointer on Binary GUID**

```
Error: Failed to convert binary GUID
```

**Solution**: Check that binary fields have both `$binary` and `$type` properties.

### Debug Logging

Enable debug logging in your Kafka Connect worker:

```properties
log4j.logger.com.pazarama.connector.bigquery=DEBUG
```

## Performance Tuning

1. **Batch Size**: Increase `bigquery.batch.size` for higher throughput (500-5000)
2. **Tasks**: Increase `tasks.max` for parallel processing
3. **Timeout**: Adjust `bigquery.batch.timeout.ms` based on your latency requirements
4. **Retries**: Configure `bigquery.max.retries` and `bigquery.retry.backoff.ms` for reliability

## Limitations

- Maximum BigQuery record size: 10 MB
- Maximum batch size: 10,000 rows or 10 MB
- Field name restrictions: Must start with letter/underscore, contain only alphanumeric and underscores
- Nested arrays (arrays of arrays) are not fully supported by BigQuery

## License

Apache License 2.0

## Contributing

Contributions are welcome! Please submit pull requests or open issues.

## Support

For issues and questions:
- GitHub Issues: [Create an issue](https://github.com/pazarama/kafka-connect-bigquery-cdc-sink-connector/issues)
- Documentation: See this README

## Project Structure

```
kafka-connect-bigquery-cdc-sink-connector/
├── src/
│   ├── main/
│   │   ├── java/com/pazarama/kafka/connect/bigquery/
│   │   │   ├── BigQuerySinkConnector.java
│   │   │   ├── BigQuerySinkTask.java
│   │   │   ├── config/
│   │   │   │   └── BigQuerySinkConnectorConfig.java
│   │   │   ├── converter/
│   │   │   │   └── SchemaConverter.java
│   │   │   ├── utils/
│   │   │   │   ├── GuidConverter.java
│   │   │   │   └── JsonPayloadProcessor.java
│   │   │   └── writer/
│   │   │       ├── BigQueryTableManager.java
│   │   │       └── BigQueryWriter.java
│   │   └── resources/
│   │       ├── connector-manifest.json
│   │       └── version.properties
│   └── test/
│       └── java/com/pazarama/kafka/connect/bigquery/
│           └── utils/
│               ├── GuidConverterTest.java
│               └── JsonPayloadProcessorTest.java
├── config/
│   ├── connector.properties (MongoDB example)
│   └── connector-mssql.properties (MSSQL example)
├── pom.xml
├── build.sh
└── README.md
```
